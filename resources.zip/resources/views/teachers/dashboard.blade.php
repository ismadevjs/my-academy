@extends('teachers.layouts.master')

@section('content')
    hello from teacher dashboard
@endsection