@extends('students.layouts.master')

@section('content')
    hello from students dashboard
@endsection